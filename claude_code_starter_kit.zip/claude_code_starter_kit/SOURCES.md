# Source register and evidence assessment

Retrieved 25 October 2026. Documentation is rolling. Reddit reports are observations and candidate ideas, not controlled estimates. Relative post ages differed across indexed and rendered views, so exact Reddit publication dates are not assigned here.

## Primary guidance

| Source | What it supports |
| --- | --- |
| [Claude Code best practices](https://code.claude.com/docs/en/best-practices) | Runnable acceptance evidence, focused context, and review guidance with a warning about speculative findings. |
| [Memory and CLAUDE.md](https://code.claude.com/docs/en/memory) | Loading, imports, scoped instructions, conflicts, and auditing. |
| [Hooks reference](https://code.claude.com/docs/en/hooks) | Actual event schemas and blocking semantics; implementation details must be checked against the installed version. |
| [Hooks guide](https://code.claude.com/docs/en/hooks-guide) | Deterministic automation of suitable repeatable actions. |
| [Skills](https://code.claude.com/docs/en/skills) | Occasional procedures can be invoked when relevant. |
| [Permissions](https://code.claude.com/docs/en/permissions) | Configuring access boundaries. |
| [Sandboxing](https://code.claude.com/docs/en/sandboxing) | Scope of shell isolation and processes outside it. |
| [Opus 5 prompting](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-5) | Avoid redundant verification scaffolding for that model. |
| [Opus 5.5 prompting](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-5-5) | Recalibrate effort; earlier Opus 5 guidance remains a starting point. |
| [Sonnet 5.5 prompting](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-sonnet-5-5) | Respond to observed skipped verification, especially at low effort. |
| [Fable 5.1 prompting](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-fable-5-1) | Keep scope and permanent test additions proportionate to the task. |
| [Harness design for long-running applications](https://www.anthropic.com/research/harness-design-long-running-apps) | Evaluate whether extra components still contribute as capabilities change. |
| [uv locking/syncing](https://docs.astral.sh/uv/concepts/projects/sync/) | Correct lockfile/environment command semantics. |
| [Ruff formatter](https://docs.astral.sh/ruff/formatter/) | Formatting and non-mutating format checks. |
| [Hypothesis stateful tests](https://hypothesis.readthedocs.io/en/latest/stateful.html) | Comparison with a simpler model as a testing technique. |

## Empirical research

### Evaluating AGENTS.md — September 29, 2026 revision

[Paper, v3](https://arxiv.org/html/2602.11988)

The study found no general improvement in task success and increased average inference cost. Its tasks and models do not establish effects on every present-day repository or on human readability. It supports evaluating repository-specific guidance, rather than assuming a generic generated overview helps.

### Guardrails Beat Guidance — May 28, 2026 revision

[Paper, v2](https://arxiv.org/html/2604.11088v2)

The headline experiments use a selected 58-task subset; rule ablations use 35 tasks. Individual rule-set comparisons are not statistically significant, and the strongest individual ablation would not survive correction across the tested rules. Negative constraints differ in substance from positive directives, so the study does not isolate a universal effect of grammatical polarity. Treat its scope-control result as suggestive.

### Probe-and-Refine Tuning of Repository Guidance — June 19, 2026 revision

[Abstract, v2](https://arxiv.org/abs/2606.20512v2)

The reported gains support testing guidance against diagnostic tasks. They were measured in a particular model and benchmark setup and do not establish that an automatically growing instruction file will help Claude Code. Only the abstract was inspected for this source.

## Selected Reddit discussions

| Thread | Useful lesson and qualification |
| --- | --- |
| [What to include in CLAUDE.md](https://www.reddit.com/r/ClaudeCode/comments/1rohbj0/what_to_include_in_claudemd_and_what_not/) | Non-obvious facts and pointers are stronger candidates than duplicated general advice. |
| [Rules that actually made a difference](https://www.reddit.com/r/ClaudeCode/comments/1t50jvq/the_claudemd_rules_that_actually_made_a/) | Concrete scope boundaries; comments also include unsupported theories of model internals. |
| [Stopping over-engineering](https://www.reddit.com/r/ClaudeCode/comments/1tgkhep/how_i_stopped_claude_code_from_overengineering/) | Actual workload and constraints matter more than blanket engineering slogans. |
| [TDD in professional use](https://www.reddit.com/r/ClaudeAI/comments/1ot02iz/who_has_actually_been_using_tdd_consistently_with/) | Reports both benefits and brittle implementation-coupled test suites. |
| [Self-review without repeated prompting](https://www.reddit.com/r/ClaudeCode/comments/1vjoyc3/does_anyone_actually_get_claude_code_to/) | Users report review loops that never finish; supports bounding the workflow. |
| [Trade-offs between hooks and instructions](https://www.reddit.com/r/ClaudeCode/comments/1sreeku/trade_off_between_hooks_and_claudemd_for_listing/) | Duplicated lint/type/test commands across several layers create repeated work. |
| [Stopped writing rules, started writing hooks](https://www.reddit.com/r/ClaudeAI/comments/1ucnasw/i_stopped_writing_rules_in_claudemd_and_started/) | Read countercomments on bypasses and editable hooks alongside the enthusiastic headline. |
| [Stop hook before done](https://www.reddit.com/r/ClaudeAI/comments/1x5jh98/a_stop_hook_that_makes_claude_code_run_the_tests/) | A loop guard alone does not verify an attempted repair. |
| [MISTAKES.md](https://www.reddit.com/r/ClaudeCode/comments/1vn6d5r/i_make_claude_code_keep_a_mistakesmd_file_heres/) | Candidate lessons need a retrieval/promotion mechanism and a verified cause. |
| [Classifying 79 rules before deletion](https://www.reddit.com/r/ClaudeCode/comments/1vd9qfm/i_sorted_all_79_rules_in_my_claudemd_against/) | Distinguishes model workarounds, environment facts, and deliberate preferences. |
| [One line with the biggest difference](https://www.reddit.com/r/ClaudeCode/comments/1xeautc/whats_the_one_line_in_your_claudemd_that_made_the/) | Batch-reading may help; freezing all reads and running tests exactly once blocks adaptive feedback. |
| [Single best thing: verify original sources](https://www.reddit.com/r/ClaudeCode/comments/1uqwo05/the_single_best_thing_ive_put_in_claudemd/) | Rechecking mutable evidence helps; always reloading every source is excessive. |
| [Large-codebase instruction files](https://www.reddit.com/r/ClaudeAI/comments/1mgfy4t/highly_effective_claudemd_for_large_codebasees/) | Scoping can matter; splitting alone does not establish lower loaded context. |
| [Split into 27 files](https://www.reddit.com/r/ClaudeCode/comments/1rhe89z/i_split_my_claudemd_into_27_files_heres_the/) | A maintenance anecdote, not evidence that a large number of files improves coding. |
| [Always stale CLAUDE.md](https://www.reddit.com/r/ClaudeAI/comments/1rkya1a/my_claudemd_is_always_stale_by_the_time_i_need_it/) | Stale commands and references can undermine concise instructions. |
| [Hook blocks rm, alternate executable bypasses it](https://www.reddit.com/r/ClaudeCode/comments/1r8azcc/your_pretooluse_hook_blocks_all_rm_rf_patterns/) | Matching one command spelling is not complete control of the underlying action. |

## Interpretation

No source establishes a numeric probability that this exact kit will improve your code. The recommendation combines verified product behavior, observed failure patterns, and engineering mechanisms. The strongest confidence is in faithfully executed deterministic checks for properties they actually measure. Semantic correctness still depends on the specification, test quality, and review. Readability requires a human judgment beyond formatter compliance.
