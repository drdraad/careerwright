# Hook design and acceptance criteria

The event configuration below follows Anthropic's current API. The behavioral contracts and receipt design are engineering recommendations for this setup. They have not been integrated with a user repository.

## 1. PostToolUse: cheap, deterministic formatting

On a successful edit, format the affected supported file using the project's existing configuration. Keep the operation synchronous, idempotent, and limited to that file. A Python example is `uv run --locked ruff format <file>`; a non-mutating verification step uses `ruff format --check`. See [Ruff's formatter documentation](https://docs.astral.sh/ruff/formatter/).

Do not make a full test suite part of each individual edit. Several related edits may be needed before the program is coherent. If formatting already happens reliably in the editor or another hook, retain a single owner of this action.

The dispatcher should parse the JSON input, validate the target path, resolve the active repository, and pass arguments as an argument vector rather than interpolating an untrusted filename into a shell command. Reject paths outside the configured workspace. Unsupported file types are a normal no-op.

## 2. Stop: bounded verification feedback

At a meaningful completion boundary, check the code that is being delivered using the agreed repository command. Distinguish:

- **Passed:** the selected checks ran successfully on the current inputs.
- **Failed:** a check ran and found a failure.
- **Blocked:** dependencies, credentials, an external service, or another prerequisite prevented checking.
- **Stale:** code or other relevant inputs changed after or during checking.
- **Not required:** the turn did not create a candidate needing these checks; this is not a pass.

Start with at most one automatic repair opportunity. On another failure, surface the failed or blocked result for the user and CI rather than cycling indefinitely. The retry budget is a starting design choice to measure, not a universal optimum.

The `stop_hook_active` flag is a loop-control signal. An early return based on that flag must never be treated as evidence that the attempted repair passed. After a repair, either verify the current code or explicitly leave its status unverified.

A completion hook runs at conversational stopping boundaries, which need not correspond to a finished implementation. Decide how coding turns and relevant changes are identified before enabling it globally. Initialization may record a workspace baseline; no-code turns should not trigger repairs of unrelated pre-existing work. If that distinction cannot be made reliably, use an explicit verification workflow until it can.

## Current API notes

Command hooks receive JSON on stdin. Matching handlers can run concurrently. Use one ordered dispatcher for dependent steps. `Edit|Write` does not cover writes through other tools. Async checks cannot block. Use documented JSON or event-appropriate exit-2 feedback or blocking; exit 1 is usually nonblocking. The input `cwd` identifies the active location, while `CLAUDE_PROJECT_DIR` may still identify the initial checkout. See the [hooks reference](https://code.claude.com/docs/en/hooks).

The following is an **illustrative settings fragment**. It needs a repository-specific `quality.py` implementation and measured timeout values. Read the event contracts above before using it.

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "python3",
            "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/quality.py", "format"],
            "timeout": 15
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3",
            "args": ["${CLAUDE_PROJECT_DIR}/.claude/hooks/quality.py", "verify"],
            "timeout": 60
          }
        ]
      }
    ]
  }
}
```

The dispatcher must locate the active checkout from its input, including when the session moves to a worktree. The script path in this example intentionally identifies the installed dispatcher; it does not identify the files to verify.

## 3. Advanced option: results tied to their inputs

Add caching only if measurements show repeated checking is material. A global Boolean such as `tests_passed = true` loses the essential information: which code, checks, and environment produced that result.

Define a verification key:

`key = H(workspace identity, relevant file contents, command and checker identity, environment identity)`

Relevant inputs include source, tests, fixtures, schema or configuration, lockfiles, and untracked files that affect the checks. The command identity includes test selection and arguments. Environment identity includes relevant toolchain and dependency state. Store exit statuses and bounded diagnostic evidence with the key.

Reuse a result only when its key matches the current candidate and all selected checks succeeded. The cache is advisory local automation. CI should independently verify the submitted revision.

### Correctness conditions

1. **Define the dependency set honestly.** If you do not know what can affect a check, do not cache it. A source-only digest is insufficient when a changed fixture, dependency, configuration, or environment can change the result.
2. **Include untracked files.** Neither the commit SHA nor an ordinary tracked-file diff describes the entire candidate workspace.
3. **Treat formatting as a mutation.** Format before validating. A later format or edit invalidates the affected result.
4. **Scope state correctly.** Isolate workspace and session state; do not share a mutable global pass flag across agents.
5. **Avoid races.** Serialize checks and state updates. Comparing digests before and after checking is useful with a single writer, but it is not equivalent to snapshot isolation. For stronger assurance, verify an isolated immutable snapshot and bind the result to that snapshot.
6. **Restrict reuse.** Checks involving live databases, time, randomness, mutable services, or changing credentials need an explicit validity policy; often rerunning is simpler and safer than caching.
7. **Preserve failure truth.** Timeouts, crashed checkers, zero collected tests where tests were required, and missing dependencies must not produce a successful receipt.
8. **Do not trust agent-editable receipts as a merge gate.** Protect the external verification policy and run required checks independently.

This feature is a proposed extension, not a built-in Claude Code certification mechanism. Its value is eliminating stale evidence and duplicate deterministic work. A poor dependency model can make it less reliable than straightforward reruns.

## 4. Optional PreToolUse policy

Use a pre-execution hook for a narrow, observable policy after a real need appears: for example, detecting direct edits to generated files and identifying the correct generator. Keep checks transparent and actionable.

Treat command-pattern blocks as coverage-limited checks. Equivalent actions can occur through another executable or tool. Project instructions and hooks should not be the sole control over credentials, deployment, or consequential data writes. Configure appropriate [permissions](https://code.claude.com/docs/en/permissions) and execution isolation.

Hooks run outside Claude Code's Bash sandbox. A hook that launches repository tests executes that repository's code with the hook process's privileges. Use a separately isolated runner where that matters. See [sandbox scope](https://code.claude.com/docs/en/sandboxing).

## 5. Acceptance cases for implementation

Validate the hook using realistic cases before treating it as a required workflow:

| Case | Required outcome |
| --- | --- |
| One supported file edited | Only that file is formatted; repeated formatting is unchanged. |
| Filename includes spaces or shell metacharacters | Treated as data; no command interpolation. |
| Source changed through a shell command | Final verification sees the resulting content. |
| New untracked source or test added | Included in the candidate and any verification key. |
| Test/config/fixture/lockfile changed | Affected prior result is invalidated. |
| Code changes while tests run | Result is not accepted for the new candidate. |
| Checker succeeds, then formatter changes source | Earlier result is stale. |
| First verification fails | Concise, actionable feedback; one bounded repair opportunity. |
| Repair still fails or cannot run | Explicit failed/blocked result; no pass receipt. |
| Existing unrelated failure | Identified with evidence; no automatic unrelated repair. |
| Two worktrees or agents active | No shared pass flag or cross-worktree result. |
| Analysis-only turn | No misleading pass and no unrelated repair loop. |
| Hook missing, crashes, or times out | Observed as failure of the mechanism; CI still controls acceptance. |

Measure check runtime and diagnostic volume. Keep successful hook output quiet and failures concise. Add complexity only when a specific observed failure justifies it.
