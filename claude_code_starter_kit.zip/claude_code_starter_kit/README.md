# Claude Code: a compact quality setup

Research checked: **25 October 2026**.

This kit accompanies a research recommendation for producing correct, readable code with a small instruction set. Its components are a repository contract, deterministic feedback, and a review procedure for changes whose consequences justify an additional independent check.

## Adopt in this order

1. Establish working setup and verification commands. Use the repository's existing formatter, linter, type checker, and test runner. Choose a fast local check and a full acceptance check. Reuse the underlying checks in CI.
2. Replace every angle-bracket placeholder in `CLAUDE.md`. Delete unused fact lines. Keep only information that changes decisions: hidden invariants, unusual commands, compatibility constraints, and useful representative code. The file is a template, not a description of your repository.
3. Adapt the two hook contracts in `HOOK_DESIGN.md`. The formatter is optional when an existing mechanism already performs the same job. The completion check should provide bounded feedback, with a clear failed or unverified outcome when validation cannot be completed.
4. Invoke the prompt in `REVIEW_AND_EVALUATION.md` for a consequential behavioral change. Keep routine work on the ordinary path.
5. Compare the setup with a minimal baseline on representative tasks, and remove components that add cost without an observed benefit.

## Files

| File | Purpose |
| --- | --- |
| `CLAUDE.md` | Copyable, concise repository instruction template; replace its placeholders first. |
| `HOOK_DESIGN.md` | Precise integration contracts, an illustrative settings shape, freshness design, and acceptance cases. |
| `REVIEW_AND_EVALUATION.md` | Original bounded reviewer prompt and a practical evaluation method. |
| `SOURCES.md` | Primary documentation, research, and selected Reddit discussions with evidence caveats. |

Hook implementation requires the actual repository's commands, input dependencies, runtime budget, and execution environment. The settings shown in the design document refer to a `quality.py` dispatcher to be implemented for that repository; this archive does not install executable hooks.

## Tailoring to Python and uv

When a project uses uv and a checked-in lockfile, commands such as `uv run --locked ruff check .` can form part of verification. `--locked` rejects an outdated lockfile rather than silently updating it; `--frozen` skips that currency check. Select the project's required dependency groups and extras. See [uv locking and syncing](https://docs.astral.sh/uv/concepts/projects/sync/).

Use the established formatter and type checker. Adding a second checker solely for the agent usually creates extra policy and maintenance work. A verification command should preserve nonzero exit codes and report checks that could not start distinctly from checks that passed.
