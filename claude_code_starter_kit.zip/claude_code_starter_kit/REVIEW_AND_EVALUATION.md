# Independent review and evaluation

## When a separate review is worthwhile

Use a dedicated review for material changes to authorization, money, data contracts, concurrency, migrations, or algorithms, and for autonomous work beyond the model's demonstrated reliability. These triggers are engineering judgment. Adapt them to the repository's actual risks.

The [Anthropic harness-design article](https://www.anthropic.com/research/harness-design-long-running-apps) describes benefits from an evaluator on difficult application work and removing scaffolding as stronger models made parts of it unnecessary. This supports measuring the marginal value of review. It does not establish a universal benefit for every patch.

Current [Opus 5 guidance](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/prompting-claude-opus-5) warns that mandatory extra verification prompts can add cost without improving quality. Treat a separate review as a deliberately selected workflow, rather than an automatic instruction on every turn.

## Original review prompt

Give a fresh reviewer the requirements, relevant interfaces, patch, access to surrounding code, and executed-check results. Keep the implementer's persuasive explanation out of the initial briefing.

> Review this change against the stated requirements and existing contracts. Report actionable correctness defects introduced by the change and requested behavior that is missing. For each finding, identify the location, a reproducer or precise failing execution path, its impact, and severity. Verify the surrounding code before asserting a defect. Distinguish demonstrated defects from unresolved uncertainty. There is no target number of findings; return none when the evidence supports none. Keep stylistic preferences, unrelated pre-existing problems, and hypothetical requirements out of the findings. If a new abstraction is unnecessary, identify the simpler equivalent and explain how it preserves the required behavior. Do not edit the patch during this review.

Start with one review pass, then resolve supported findings and revalidate changed behavior. An additional pass should have a specific reason. Severity and confidence are separate: a small certain defect can be worth fixing, while a severe imagined failure is not established evidence.

## A useful variation for mathematical and data code

Before reading the implementation's explanation, derive a tiny independent oracle or invariant from the specification. Then use it to try to falsify the candidate. Examples:

- For a small optimisation instance, enumerate feasible solutions and compare feasibility and objective values. Match objective direction, tolerances, and tie semantics; do not assume the optimum is unique.
- For a transformation, use a manually derived fixture containing duplicate keys, nulls, and a boundary timestamp where those inputs are allowed.
- For an idempotent operation, check that repeating the operation preserves the specified state.
- For an ordering-independent operation, permute inputs and compare the appropriate outputs.

These properties must follow from the specification. Floating-point reductions need not be exactly permutation invariant, random algorithms need an explicit randomness contract, and adding data is not always monotone. An incorrect oracle can reject correct code or reward a shared misunderstanding.

The aim is an independent source of evidence. A second agent using the same model can still make correlated errors. An existing trusted reference, manually checked example, or exhaustive small-instance search can provide stronger independence than a second verbal opinion. Validate the oracle itself before relying on it.

[Hypothesis's stateful-testing documentation](https://hypothesis.readthedocs.io/en/latest/stateful.html) demonstrates comparing an implementation with a simpler model. That supports the testing technique; it does not validate an LLM-generated oracle automatically. Where practical, confirm the proposed check rejects a meaningful known-bad case as well as accepting hand-worked correct cases.

## Evaluate the whole setup

Keep the model version, effort, tools, environment, starting revision, and task wording fixed within comparisons. Use fresh sessions and independent checkouts to prevent memory and patch leakage. Include multiple runs when affordable.

Compare:

1. Commands and essential repository facts only.
2. The concise behavioral contract added.
3. The contract plus deterministic hooks.
4. Selective review added only for the risk cases it targets.

A screening set of 12–20 tasks can reveal large regressions and workflow problems. It cannot establish small universal improvements. Include ordinary edits, a real bug, a multi-file behavior change, a dependency mismatch, a pre-existing unrelated failure, and a task that activates each proposed specialist rule.

Use acceptance checks independent of the agent's proposed tests, and have a reviewer compare code without knowing which condition produced it. Record:

- Correctness against acceptance criteria and regressions.
- Unsupported claims of completion or successful checking.
- Human edits required before approval, especially to control flow, naming, and unnecessary abstractions.
- Unrelated changes and unnecessary dependencies.
- Elapsed time, tokens/cost, duplicate checks, hook failures, and retry loops.

Report paired task results and variation; do not treat every repeated trajectory as an independent new task. If evaluating small differences formally, use uncertainty estimates that respect task clustering. Check interactions: a review prompt and a Stop hook can each help alone yet create churn together.

The staged comparison above measures incremental package effects. To isolate an instruction–hook interaction, use the full four conditions: baseline, instructions alone, hooks alone, and both. Reserve a small holdout set or test prospectively after tuning; repeatedly optimizing every instruction against the same failures can overfit the pilot.

## Maintain a small instruction set

Record an observed failure and its suspected cause separately from permanent instructions. Confirm the cause using code or a reproducible example. Prefer an executable assertion, regression test, linter, type rule, or isolated permission boundary when it can encode the lesson accurately. Promote residual contextual knowledge to the narrowest appropriate instruction scope.

Keep a maintenance record outside startup context: the trigger, evidence, remedy, owner, and review date. Retest model-compensating instructions after model upgrades. Preserve real environment facts and deliberate preferences. A week without a migration does not show that a migration rule is unnecessary.

Correctness is the primary objective; lower cost is useful only after the accepted quality standard is met.
