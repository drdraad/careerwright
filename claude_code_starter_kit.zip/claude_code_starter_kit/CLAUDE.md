# Repository contract

## Commands
- Setup: `<SETUP>`
- Fast checks: `<FAST>`
- Full acceptance checks: `<FULL>` — the command used by CI.

## Repository facts
- Representative implementation: `<PATH>` — `<what it demonstrates>`.
- Non-obvious invariant: `<CONSTRAINT and its reason>`.
- Compatibility boundary: `<PUBLIC API / SCHEMA / SUPPORTED VERSIONS>`.

## Change scope
- If ambiguous or conflicting instructions materially affect behavior, scope,
  or acceptance criteria, ask for clarification before implementing the affected part.
- Deliver the requested behavior completely, using the simplest clear design
  that fits the surrounding code.
- Keep unrelated cleanup, new dependencies, and speculative extension points
  out of the change. Include wider changes when the requested result needs them.
- Preserve behavior outside the requested change and identify intentional
  changes to public behavior or compatibility.

## Correctness
- For changed behavior, identify observable acceptance criteria.
- For bug fixes, prefer a focused reproducer that fails for the reported behavior
  before the fix, when practical.
- Treat existing tests as evidence of the contract. Change expectations only
  when the intended behavior changes or an expectation is demonstrably wrong.
- Preserve valid assertions; do not suppress failures to obtain a passing result.
- Keep failure distinguishable from success. Do not mask errors with empty results,
  misleading statuses, or silent behavior changes. Without an authorized fallback,
  use the existing error mechanism to make failure observable to the caller and
  diagnosable with actionable context.
- Use fallbacks only when requirements or an established contract authorize them.
  Obtain approval before introducing a fallback that changes agreed behavior.

## Completion
- Report what changed, checks actually run and their results, and remaining gaps.
- Evidence must apply to the final code; stale or failed-to-start checks are not passes.
- Stop when the requested result is established. Further checking should address
  a concrete unresolved risk.
- If validation is blocked or an unrelated check fails, report that clearly;
  do not silently expand scope or claim the change is verified.
